use anyhow::{ensure, Result};

fn main() -> Result<()> {
    ensure!();
    Ok(())
}
