# debugserver-types [![Build Status](https://travis-ci.org/Marwes/debugserver-types.svg?branch=master)](https://travis-ci.org/Marwes/debugserver-types) [![Documentation](https://docs.rs/debugserver-types/badge.svg)](https://docs.rs/crate/debugserver-types)

Automatically generated type definitions for VSCode's debug server protocol

# References

https://code.visualstudio.com/docs/extensions/example-debuggers
