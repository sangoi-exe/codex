use serde::{Deserialize, Serialize};

schemafy::schemafy!("src/schema.json");
