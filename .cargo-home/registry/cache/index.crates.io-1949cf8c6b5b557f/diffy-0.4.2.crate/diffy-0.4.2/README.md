# diffy

[![diffy on crates.io](https://img.shields.io/crates/v/diffy)](https://crates.io/crates/diffy)
[![Documentation (latest release)](https://docs.rs/diffy/badge.svg)](https://docs.rs/diffy/)
[![Documentation (master)](https://img.shields.io/badge/docs-master-59f)](https://bmwill.github.io/diffy/diffy/)
[![License](https://img.shields.io/badge/license-Apache-green.svg)](LICENSE-APACHE)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE-MIT)

Tools for finding and manipulating differences between files

## License

This project is available under the terms of either the [Apache 2.0
license](LICENSE-APACHE) or the [MIT license](LICENSE-MIT).
