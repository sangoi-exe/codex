# @generated
# To regenerate, run:
# ```
# STARLARK_RUST_REGENERATE_GOLDEN_TESTS=1 cargo test -p starlark --lib
# ```

# submod

## new\_obj

```python
def new_obj() -> obj
```

---

## notypes

```python
def notypes(a)
```

---

## starlark\_args

```python
def starlark_args(*args: str) -> None
```

---

## starlark\_kwargs

```python
def starlark_kwargs(**kwargs: int) -> None
```
