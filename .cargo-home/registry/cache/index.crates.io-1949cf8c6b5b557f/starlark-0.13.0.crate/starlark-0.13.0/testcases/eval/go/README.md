# Go evaluation test cases

The Go Starlark project maintains a set of test cases, which were mirrored here.
The original source is
https://github.com/google/starlark-go/blob/e81fc95f7bd5bb1495fe69f27c1a99fcc77caa48/starlark/testdata/.
Note that some files were not copied, because they are unsuitable tests for
Starlark, as described in the `test_go` function.
