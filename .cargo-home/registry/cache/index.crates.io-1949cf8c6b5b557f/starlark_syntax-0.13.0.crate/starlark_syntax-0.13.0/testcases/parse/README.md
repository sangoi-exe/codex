# Parsing test cases

A set of `.bzl` files taken from various open-source projects to test the
Starlark parser against real world cases.

Files are marked generated, that was done to mute linters. There's no automation
to regenerate these files.
